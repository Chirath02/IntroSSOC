python payload > exploit.txt
