python keygen.py $@
