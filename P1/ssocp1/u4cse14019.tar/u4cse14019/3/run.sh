python rotate.py $@
